if (window.addEventListener) {
    window.addEventListener("message", onMessage, false);
} else if (window.attachEvent) {
    window.attachEvent("onmessage", onMessage, false);
}

const referenceTabId = parseInt(window.location.search.substr(1).split("=")[1]);

function onMessage(event) {
    const data = event.data;
    if (typeof (window[data.func]) == "function") {
        window[data.func].call(null, data.message);
    }
}

// Function to be called from iframe
function openUrl(message) {
    chrome.runtime.sendMessage({ type: "openLink", linkUrl: message, tabId: referenceTabId });
}