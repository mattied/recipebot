chrome.sidePanel
	.setPanelBehavior( {openPanelOnActionClick: true})
	.catch((err) => console.error(err));

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
	if (message.type == "openLink") {
		chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
		  var tabId = tabs[0].id;
		  chrome.tabs.update(tabId, { url: message.linkUrl });
		});
	}
});
